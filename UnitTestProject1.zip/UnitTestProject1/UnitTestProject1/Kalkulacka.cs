﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    internal class Kalkulacka
    {
        static public int cislo1;
        static public int cislo2;

        static public int Soucet(int cislo1, int cislo2)
        {
            return cislo1 + cislo2;
        }

        static public double Podil(int cislo1, int cislo2)
        {
            return cislo1 / cislo2;
        }
    }
}

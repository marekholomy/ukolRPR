﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    internal class RPR
    {
        static public bool obsahujeRPR(string s)
        {
            if (s.Contains("RPR"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static public bool dlouhe(string s)
        {
            if (s.Length >= 8 && s.Length <= 20)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static public bool neprazdne(string s)
        {
            if (s.Length != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

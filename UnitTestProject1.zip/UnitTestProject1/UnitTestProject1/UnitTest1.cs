﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestSoucetPOS() // Pozitivní
        {
            int skutecnost = Kalkulacka.Soucet(5,5); // skutečný výsledek PRG
            int predstava = 10; // Teoretická představa výsledku
            Assert.AreEqual(skutecnost, predstava); // Porovnání představy se skutečností
        }

        [TestMethod]
        public void TestSoucetNEG() // Negativní
        {
            int skutecnost = Kalkulacka.Soucet(5, 9); // skutečný výsledek PRG
            int predstava = 10; // Chybná představa
            Assert.AreEqual(skutecnost, predstava); // Porovnání představy se skutečností
        }

        [TestMethod]
        public void TestPodilPOS() // Pozitivní
        {
            double vysledek = Kalkulacka.Podil(5, 5);
            double predstava = 1;
            Assert.AreEqual(predstava, vysledek);
        }

        [TestMethod]
        public void TestPodilNEG() // Negativní
        {
            double vysledek = Kalkulacka.Podil(7, 5);
            double predstava = 1;
            Assert.AreEqual(predstava, vysledek);
        }

        [TestMethod]
        public void TestPodil2POS() // Pozitivní
        {
            double vysledek = Kalkulacka.Podil(3, 2);
            double predstava = 1.5;
            Assert.AreEqual(predstava, vysledek);
        }

        [TestMethod]
        public void TestPodil2NEG() // Negativní
        {
            double vysledek = Kalkulacka.Podil(3, 2);
            double predstava = 1.88;
            Assert.AreEqual(predstava, vysledek);
        }

        [TestMethod]
        public void TestPodil3POS() // Pozitivní
        {
            double vysledek = Kalkulacka.Podil(3, 0);
            Assert.IsFalse(double.IsInfinity(vysledek));
        }

        [TestMethod]
        public void TestPodil3NEG() // Negativní
        {
            double vysledek = Kalkulacka.Podil(3, 0);
            Assert.IsTrue(double.IsInfinity(vysledek));
        }

        [TestMethod]
        public void TestRPRPOS() // Pozitivní
        {
            bool vysledek = RPR.obsahujeRPR("CauRPR");
            Assert.IsTrue(vysledek);
        }

        [TestMethod]
        public void TestRPRNEG() // Negativní
        {
            bool vysledek = RPR.obsahujeRPR("Cau");
            Assert.IsTrue(vysledek);
        }

        [TestMethod]
        public void TestRPR1POS() // Pozitivní
        {
            bool vysledek = RPR.dlouhe("jaksemassema");
            Assert.IsTrue(vysledek);
        }

        [TestMethod]
        public void TestRPR1NEG() // Negativní
        {
            bool vysledek = RPR.dlouhe("Cau");
            Assert.IsTrue(vysledek);
        }

        [TestMethod]
        public void TestRPR2POS() // Pozitivní
        {
            bool vysledek = RPR.neprazdne(":)");
            Assert.IsTrue(vysledek);
        }

        [TestMethod]
        public void TestRPR2NEG() // Negativní
        {
            bool vysledek = RPR.neprazdne("");
            Assert.IsTrue(vysledek);
        }
    }
    
}
